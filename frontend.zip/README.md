# LocalPro Services - Modern PWA Website

A sleek and modern Progressive Web App (PWA) for connecting clients with local professionals across six main service categories: Plumbing, Electrical, Mechanical, Carpentry, Painting, and Cleaning.

## 🚀 Features

### Core Functionality
- **Service Discovery**: Browse and filter services by category, location, and rating
- **User Authentication**: Secure login/signup with form validation
- **Booking System**: Complete booking flow with date/time selection
- **Dashboard**: User dashboard for managing bookings and profile
- **PWA Support**: Installable app with offline functionality

### Service Categories
1. **🪠 Plumbing** - Pipe installation, repairs, drainage, etc.
2. **⚡ Electrical** - Wiring, lighting, appliance repair, etc.
3. **⚙️ Mechanical** - Vehicle repair, AC maintenance, etc.
4. **🪚 Carpentry** - Furniture making, door fitting, etc.
5. **🎨 Painting** - Interior/exterior painting, decorative work, etc.
6. **🧹 Cleaning** - Home, office, carpet cleaning, etc.

## 🛠 Tech Stack

- **Frontend**: HTML5, TailwindCSS, Vanilla JavaScript
- **PWA**: Service Worker, Web App Manifest
- **Storage**: LocalStorage for demo data
- **Icons**: Emoji-based service icons
- **Responsive**: Mobile-first design

## 📁 Project Structure

```
forkG/
├── index.html              # Homepage
├── services.html           # Services listing page
├── login.html             # Authentication page
├── booking-schedule.html   # Booking form
├── booking-confirmation.html # Booking review
├── booking-success.html    # Success confirmation
├── dashboard.html         # User dashboard
├── manifest.json          # PWA manifest
├── sw.js                 # Service worker
├── styles.css            # Additional CSS
├── js/
│   ├── app.js            # Main application logic
│   ├── services.js       # Services page functionality
│   ├── auth.js           # Authentication logic
│   ├── booking.js        # Booking system
│   └── dashboard.js      # Dashboard functionality
└── README.md             # This file
```

## 🎨 Design System

### Colors
- **Primary**: `#1E88E5` (Professional Blue)
- **Accent**: `#FFB300` (Golden Yellow)
- **Neutral**: `#F9FAFB` (Light Gray Background)
- **Text**: `#212121` (Dark Gray)

### Components
- Modern card-based layout
- Responsive grid system
- Interactive buttons and forms
- Toast notifications
- Loading states
- Modal dialogs

## 🚀 Getting Started

1. **Clone or Download** the project files
2. **Open** `index.html` in a web browser
3. **Navigate** through the different pages
4. **Test** the booking flow and dashboard features

### For Development
1. Use a local server (e.g., Live Server extension in VS Code)
2. Open `http://localhost:5500` or your local server URL
3. Test PWA features (requires HTTPS in production)

## 📱 PWA Features

- **Installable**: Add to home screen on mobile devices
- **Offline Support**: Cached pages work without internet
- **Push Notifications**: Service updates and reminders
- **Background Sync**: Sync data when connection restored

## 🔧 Key Functionality

### Authentication
- Login/Signup with validation
- Password strength checking
- Remember me functionality
- Social login integration ready

### Service Discovery
- Category-based filtering
- Search functionality
- Location-based results
- Rating and review system

### Booking System
- Multi-step booking process
- Date/time selection
- Address input with GPS detection
- Booking confirmation and tracking

### Dashboard
- Booking management
- Profile settings
- Review system
- Service history

## 📊 Demo Data

The application uses localStorage to simulate backend functionality:
- Sample service providers
- Mock booking data
- User authentication simulation
- Service categories and subcategories

## 🌐 Browser Support

- Chrome 60+
- Firefox 55+
- Safari 11+
- Edge 79+
- Mobile browsers (iOS Safari, Chrome Mobile)

## 🔒 Security Features

- Form validation and sanitization
- XSS prevention
- Secure authentication flow
- Input validation on all forms

## 📈 Performance

- Optimized images and assets
- Lazy loading implementation
- Efficient caching strategy
- Minimal JavaScript bundle size

## 🎯 Future Enhancements

- Real backend API integration
- Payment gateway integration
- Real-time chat system
- Advanced search filters
- Provider registration system
- Rating and review system
- Push notification system
- Geolocation services

## 📞 Support

For questions or issues, please refer to the code comments or create an issue in the project repository.

## 📄 License

This project is created for demonstration purposes. Feel free to use and modify as needed.

---

**LocalPro Services** - Connecting you with trusted local professionals! 🏠⚡🔧