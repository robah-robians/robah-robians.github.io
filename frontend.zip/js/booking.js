// Booking functionality
document.addEventListener('DOMContentLoaded', function() {
    setupBookingForm();
    setMinDate();
    checkAuthStatus();
});

function setupBookingForm() {
    const form = document.getElementById('booking-form');
    form.addEventListener('submit', handleBookingSubmit);
    
    // Load saved booking data if any
    loadBookingData();
}

function setMinDate() {
    const dateInput = document.getElementById('booking-date');
    const today = new Date();
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    dateInput.min = tomorrow.toISOString().split('T')[0];
    dateInput.value = tomorrow.toISOString().split('T')[0];
}

function handleBookingSubmit(e) {
    e.preventDefault();
    
    const formData = collectFormData();
    
    if (!validateBookingForm(formData)) {
        return;
    }
    
    // Save booking data to localStorage
    localStorage.setItem('pendingBooking', JSON.stringify(formData));
    
    // Redirect to confirmation page
    window.location.href = 'booking-confirmation.html';
}

function collectFormData() {
    return {
        date: document.getElementById('booking-date').value,
        timeSlot: document.querySelector('input[name="time-slot"]:checked')?.value,
        address: document.getElementById('address').value,
        phone: document.getElementById('phone').value,
        altPhone: document.getElementById('alt-phone').value,
        notes: document.getElementById('notes').value,
        urgency: document.getElementById('urgency').value,
        serviceId: new URLSearchParams(window.location.search).get('serviceId') || 1,
        timestamp: new Date().toISOString()
    };
}

function validateBookingForm(data) {
    if (!data.date) {
        showToast('Please select a date', 'error');
        return false;
    }
    
    if (!data.timeSlot) {
        showToast('Please select a time slot', 'error');
        return false;
    }
    
    if (!data.address.trim()) {
        showToast('Please enter your address', 'error');
        return false;
    }
    
    if (!data.phone.trim()) {
        showToast('Please enter your phone number', 'error');
        return false;
    }
    
    if (!isValidPhone(data.phone)) {
        showToast('Please enter a valid phone number', 'error');
        return false;
    }
    
    // Check if date is not in the past
    const selectedDate = new Date(data.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate < today) {
        showToast('Please select a future date', 'error');
        return false;
    }
    
    return true;
}

function loadBookingData() {
    const savedData = localStorage.getItem('pendingBooking');
    if (savedData) {
        const data = JSON.parse(savedData);
        
        // Populate form with saved data
        if (data.date) document.getElementById('booking-date').value = data.date;
        if (data.timeSlot) {
            const timeSlotRadio = document.querySelector(`input[name="time-slot"][value="${data.timeSlot}"]`);
            if (timeSlotRadio) timeSlotRadio.checked = true;
        }
        if (data.address) document.getElementById('address').value = data.address;
        if (data.phone) document.getElementById('phone').value = data.phone;
        if (data.altPhone) document.getElementById('alt-phone').value = data.altPhone;
        if (data.notes) document.getElementById('notes').value = data.notes;
        if (data.urgency) document.getElementById('urgency').value = data.urgency;
    }
}

function detectLocation() {
    if (navigator.geolocation) {
        showToast('Detecting your location...', 'info');
        
        navigator.geolocation.getCurrentPosition(
            (position) => {
                // In a real app, you would reverse geocode these coordinates
                // For demo purposes, we'll use a placeholder
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                
                // Simulate reverse geocoding
                setTimeout(() => {
                    const mockAddress = `123 Main Street, City Center\nNear coordinates: ${lat.toFixed(4)}, ${lng.toFixed(4)}`;
                    document.getElementById('address').value = mockAddress;
                    showToast('Location detected successfully!', 'success');
                }, 1000);
            },
            (error) => {
                let errorMessage = 'Unable to detect location. ';
                switch(error.code) {
                    case error.PERMISSION_DENIED:
                        errorMessage += 'Location access denied.';
                        break;
                    case error.POSITION_UNAVAILABLE:
                        errorMessage += 'Location information unavailable.';
                        break;
                    case error.TIMEOUT:
                        errorMessage += 'Location request timed out.';
                        break;
                    default:
                        errorMessage += 'Unknown error occurred.';
                        break;
                }
                showToast(errorMessage, 'error');
            },
            {
                enableHighAccuracy: true,
                timeout: 10000,
                maximumAge: 60000
            }
        );
    } else {
        showToast('Geolocation is not supported by this browser.', 'error');
    }
}

function checkAuthStatus() {
    const token = localStorage.getItem('authToken');
    const user = localStorage.getItem('user');
    
    if (!token || !user) {
        // User not logged in, redirect to login with return URL
        const currentUrl = encodeURIComponent(window.location.href);
        window.location.href = `login.html?return=${currentUrl}`;
        return false;
    }
    
    // Populate user data if available
    const userData = JSON.parse(user);
    if (userData.phone) {
        document.getElementById('phone').value = userData.phone;
    }
    
    return true;
}

function isValidPhone(phone) {
    // Basic phone validation - accepts various formats
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
    return phoneRegex.test(cleanPhone) && cleanPhone.length >= 10;
}

function showToast(message, type) {
    // Create toast element if it doesn't exist
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        toast.className = 'fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg transform translate-x-full transition-transform duration-300 z-50';
        document.body.appendChild(toast);
    }
    
    // Set toast content and style
    toast.textContent = message;
    toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg transform transition-transform duration-300 z-50 ${
        type === 'success' ? 'bg-green-500 text-white' : 
        type === 'error' ? 'bg-red-500 text-white' : 
        'bg-blue-500 text-white'
    }`;
    
    // Show toast
    toast.style.transform = 'translateX(0)';
    
    // Hide after 3 seconds
    setTimeout(() => {
        toast.style.transform = 'translateX(100%)';
    }, 3000);
}

// Auto-save form data as user types
document.addEventListener('input', function(e) {
    if (e.target.closest('#booking-form')) {
        const formData = collectFormData();
        localStorage.setItem('bookingFormDraft', JSON.stringify(formData));
    }
});