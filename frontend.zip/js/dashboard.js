// Dashboard functionality
document.addEventListener('DOMContentLoaded', function() {
    checkAuthStatus();
    setupNavigation();
    loadDashboardData();
});

function checkAuthStatus() {
    const token = localStorage.getItem('authToken');
    const user = localStorage.getItem('user');
    
    if (!token || !user) {
        window.location.href = 'login.html';
        return false;
    }
    
    // Display user info
    const userData = JSON.parse(user);
    updateUserInfo(userData);
    
    return true;
}

function updateUserInfo(userData) {
    // Update user name in header and sidebar
    const userNameElements = document.querySelectorAll('[data-user-name]');
    userNameElements.forEach(el => {
        el.textContent = userData.name || 'User';
    });
    
    // Update email
    const userEmailElements = document.querySelectorAll('[data-user-email]');
    userEmailElements.forEach(el => {
        el.textContent = userData.email || '';
    });
}

function setupNavigation() {
    const navItems = document.querySelectorAll('.dashboard-nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Remove active class from all nav items
            navItems.forEach(nav => nav.classList.remove('active'));
            
            // Add active class to clicked item
            this.classList.add('active');
        });
    });
}

function showSection(sectionName) {
    // Hide all sections
    const sections = document.querySelectorAll('.dashboard-section');
    sections.forEach(section => {
        section.classList.add('hidden');
    });
    
    // Show selected section
    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) {
        targetSection.classList.remove('hidden');
    }
    
    // Update navigation active state
    const navItems = document.querySelectorAll('.dashboard-nav-item');
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.getAttribute('onclick')?.includes(sectionName)) {
            item.classList.add('active');
        }
    });
    
    // Load section-specific data
    switch(sectionName) {
        case 'bookings':
            loadBookings();
            break;
        case 'reviews':
            loadReviews();
            break;
        case 'profile':
            loadProfile();
            break;
        default:
            loadOverview();
    }
}

function loadDashboardData() {
    loadOverview();
    loadRecentBookings();
}

function loadOverview() {
    // Simulate loading dashboard stats
    const stats = {
        totalBookings: 12,
        completedBookings: 8,
        pendingBookings: 4,
        totalSpent: 1250
    };
    
    // Update stats cards (if they exist)
    updateStatsCards(stats);
}

function updateStatsCards(stats) {
    // This would update the stats cards with real data
    console.log('Dashboard stats loaded:', stats);
}

function loadRecentBookings() {
    // Sample booking data
    const recentBookings = [
        {
            id: 1,
            service: 'Pipe Installation',
            provider: 'John Smith',
            date: '2024-12-15',
            time: 'Morning',
            status: 'completed',
            icon: '🪠'
        },
        {
            id: 2,
            service: 'Socket Installation',
            provider: 'Sarah Johnson',
            date: '2024-12-18',
            time: 'Afternoon',
            status: 'pending',
            icon: '⚡'
        }
    ];
    
    // Update recent bookings section
    updateRecentBookings(recentBookings);
}

function updateRecentBookings(bookings) {
    // This would update the recent bookings display
    console.log('Recent bookings loaded:', bookings);
}

function loadBookings() {
    // Load all bookings for the bookings section
    const allBookings = [
        {
            id: 1,
            service: 'Pipe Installation',
            category: 'Plumbing',
            provider: 'John Smith',
            date: '2024-12-15',
            status: 'completed',
            icon: '🪠',
            canReview: true
        },
        {
            id: 2,
            service: 'Socket Installation',
            category: 'Electrical',
            provider: 'Sarah Johnson',
            date: '2024-12-18',
            status: 'pending',
            icon: '⚡',
            canCancel: true
        },
        {
            id: 3,
            service: 'Home Cleaning',
            category: 'Cleaning',
            provider: 'Clean Team Pro',
            date: '2024-12-20',
            status: 'confirmed',
            icon: '🧹',
            canCancel: true
        }
    ];
    
    renderBookingsTable(allBookings);
}

function renderBookingsTable(bookings) {
    // This would render the bookings table
    console.log('All bookings loaded:', bookings);
}

function loadReviews() {
    // Load user reviews
    const reviews = [
        {
            id: 1,
            service: 'Pipe Installation Service',
            provider: 'John Smith',
            date: '2024-12-15',
            rating: 5,
            comment: 'Excellent service! John arrived on time and completed the work professionally. Highly recommended!',
            canEdit: true
        }
    ];
    
    renderReviews(reviews);
}

function renderReviews(reviews) {
    // This would render the reviews section
    console.log('Reviews loaded:', reviews);
}

function loadProfile() {
    const user = JSON.parse(localStorage.getItem('user'));
    
    if (user) {
        // Populate profile form with user data
        const profileForm = document.querySelector('#profile-section form');
        if (profileForm) {
            const inputs = profileForm.querySelectorAll('input, textarea');
            inputs.forEach(input => {
                const fieldName = input.type === 'email' ? 'email' : 
                                input.type === 'tel' ? 'phone' : 
                                input.name || input.id;
                
                if (user[fieldName]) {
                    input.value = user[fieldName];
                }
            });
        }
    }
}

function viewBooking(bookingId) {
    // Navigate to booking details
    window.location.href = `booking-details.html?id=${bookingId}`;
}

function cancelBooking(bookingId) {
    if (confirm('Are you sure you want to cancel this booking?')) {
        // Simulate API call to cancel booking
        showToast('Booking cancelled successfully', 'success');
        
        // Reload bookings
        setTimeout(() => {
            loadBookings();
        }, 1000);
    }
}

function leaveReview(bookingId) {
    // Open review modal or navigate to review page
    openReviewModal(bookingId);
}

function openReviewModal(bookingId) {
    // Create and show review modal
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 class="text-xl font-semibold mb-4">Leave a Review</h3>
            <form id="review-form">
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Rating</label>
                    <div class="flex space-x-2">
                        ${[1,2,3,4,5].map(i => `
                            <button type="button" class="star-btn text-2xl text-gray-300 hover:text-yellow-400" data-rating="${i}">★</button>
                        `).join('')}
                    </div>
                </div>
                <div class="mb-4">
                    <label class="block text-sm font-medium mb-2">Comment</label>
                    <textarea rows="4" class="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary" placeholder="Share your experience..."></textarea>
                </div>
                <div class="flex space-x-4">
                    <button type="button" onclick="closeReviewModal()" class="flex-1 px-4 py-2 border rounded-lg hover:bg-gray-50">Cancel</button>
                    <button type="submit" class="flex-1 px-4 py-2 bg-primary text-white rounded-lg hover:bg-blue-600">Submit Review</button>
                </div>
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Setup star rating
    const starBtns = modal.querySelectorAll('.star-btn');
    let selectedRating = 0;
    
    starBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            selectedRating = parseInt(btn.dataset.rating);
            updateStarDisplay(starBtns, selectedRating);
        });
    });
    
    // Setup form submission
    const form = modal.querySelector('#review-form');
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        submitReview(bookingId, selectedRating, form.querySelector('textarea').value);
        closeReviewModal();
    });
}

function updateStarDisplay(starBtns, rating) {
    starBtns.forEach((btn, index) => {
        if (index < rating) {
            btn.classList.remove('text-gray-300');
            btn.classList.add('text-yellow-400');
        } else {
            btn.classList.remove('text-yellow-400');
            btn.classList.add('text-gray-300');
        }
    });
}

function closeReviewModal() {
    const modal = document.querySelector('.fixed.inset-0');
    if (modal) {
        modal.remove();
    }
}

function submitReview(bookingId, rating, comment) {
    // Simulate API call to submit review
    showToast('Review submitted successfully!', 'success');
    
    // Reload reviews
    setTimeout(() => {
        if (document.getElementById('reviews-section').classList.contains('hidden') === false) {
            loadReviews();
        }
    }, 1000);
}

function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('authToken');
        localStorage.removeItem('user');
        localStorage.removeItem('pendingBooking');
        localStorage.removeItem('bookingFormDraft');
        
        showToast('Logged out successfully', 'success');
        
        setTimeout(() => {
            window.location.href = 'index.html';
        }, 1000);
    }
}

function showToast(message, type) {
    const toast = document.createElement('div');
    toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg z-50 ${
        type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
    }`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}