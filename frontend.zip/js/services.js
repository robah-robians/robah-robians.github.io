// Services page functionality
document.addEventListener('DOMContentLoaded', function() {
    loadServices();
    setupFilters();
});

// Enhanced service data with additional details
const servicesData = [
    // Plumbing Services
    {id: 1, name: "Pipe Installation & Replacement", category: "plumbing", subcategory: "pipe-installation", description: "Professional pipe installation and replacement services", priceRange: "$80 - $150", rating: 4.8, reviews: 127, provider: "John Smith", location: "Downtown", image: "🪠"},
    {id: 2, name: "Copper Pipe Installation", category: "plumbing", subcategory: "pipe-installation", description: "High-quality copper pipe installation", priceRange: "$100 - $200", rating: 4.9, reviews: 89, provider: "Pipe Masters", location: "Midtown", image: "🪠"},
    {id: 3, name: "PVC Pipe Replacement", category: "plumbing", subcategory: "pipe-installation", description: "Durable PVC pipe replacement services", priceRange: "$70 - $140", rating: 4.7, reviews: 156, provider: "PlumbPro", location: "Suburbs", image: "🪠"},
    {id: 4, name: "Emergency Pipe Repair", category: "plumbing", subcategory: "pipe-installation", description: "24/7 emergency pipe repair services", priceRange: "$120 - $250", rating: 4.8, reviews: 203, provider: "Quick Fix Plumbing", location: "City Wide", image: "🪠"},
    {id: 5, name: "Water Line Installation", category: "plumbing", subcategory: "pipe-installation", description: "Complete water line installation and setup", priceRange: "$200 - $400", rating: 4.9, reviews: 78, provider: "AquaFlow", location: "Residential", image: "🪠"},
    
    {id: 6, name: "Kitchen Tap Repair", category: "plumbing", subcategory: "tap-repair", description: "Expert kitchen tap repair and maintenance", priceRange: "$50 - $120", rating: 4.7, reviews: 98, provider: "Fix-It Pro", location: "Downtown", image: "🪠"},
    {id: 7, name: "Bathroom Shower Repair", category: "plumbing", subcategory: "tap-repair", description: "Professional shower repair and replacement", priceRange: "$80 - $180", rating: 4.8, reviews: 134, provider: "Shower Solutions", location: "Midtown", image: "🪠"},
    {id: 8, name: "Faucet Installation", category: "plumbing", subcategory: "tap-repair", description: "New faucet installation and setup", priceRange: "$60 - $150", rating: 4.6, reviews: 67, provider: "Tap Experts", location: "Suburbs", image: "🪠"},
    {id: 9, name: "Leaky Tap Fix", category: "plumbing", subcategory: "tap-repair", description: "Quick and reliable leaky tap repairs", priceRange: "$40 - $90", rating: 4.9, reviews: 189, provider: "Drip Stop", location: "City Wide", image: "🪠"},
    {id: 10, name: "Mixer Tap Service", category: "plumbing", subcategory: "tap-repair", description: "Mixer tap repair and maintenance", priceRange: "$70 - $140", rating: 4.7, reviews: 112, provider: "Mix Masters", location: "Residential", image: "🪠"},
    
    {id: 11, name: "Drain Unblocking", category: "plumbing", subcategory: "drainage", description: "Professional drain cleaning and unblocking", priceRange: "$80 - $200", rating: 4.8, reviews: 156, provider: "Drain Busters", location: "City Wide", image: "🪠"},
    {id: 12, name: "Sewer Line Cleaning", category: "plumbing", subcategory: "drainage", description: "Complete sewer line cleaning service", priceRange: "$150 - $350", rating: 4.7, reviews: 89, provider: "Sewer Pro", location: "Downtown", image: "🪠"},
    {id: 13, name: "Kitchen Sink Drainage", category: "plumbing", subcategory: "drainage", description: "Kitchen sink drainage repair and cleaning", priceRange: "$60 - $140", rating: 4.9, reviews: 203, provider: "Kitchen Flow", location: "Residential", image: "🪠"},
    {id: 14, name: "Bathroom Drain Service", category: "plumbing", subcategory: "drainage", description: "Bathroom drain cleaning and maintenance", priceRange: "$70 - $160", rating: 4.6, reviews: 134, provider: "Bath Drain Co", location: "Suburbs", image: "🪠"},
    {id: 15, name: "Storm Drain Cleaning", category: "plumbing", subcategory: "drainage", description: "Storm drain cleaning and maintenance", priceRange: "$100 - $250", rating: 4.8, reviews: 78, provider: "Storm Solutions", location: "Industrial", image: "🪠"},
    
    // Electrical Services
    {id: 16, name: "House Rewiring", category: "electrical", subcategory: "wiring", description: "Complete house rewiring services", priceRange: "$800 - $2000", rating: 4.9, reviews: 67, provider: "Wire Masters", location: "Residential", image: "⚡"},
    {id: 17, name: "Electrical Panel Upgrade", category: "electrical", subcategory: "wiring", description: "Modern electrical panel installation", priceRange: "$500 - $1200", rating: 4.8, reviews: 89, provider: "Power Pro", location: "Suburbs", image: "⚡"},
    {id: 18, name: "Outlet Wiring", category: "electrical", subcategory: "wiring", description: "New outlet installation and wiring", priceRange: "$80 - $200", rating: 4.7, reviews: 156, provider: "Socket Solutions", location: "City Wide", image: "⚡"},
    {id: 19, name: "Circuit Installation", category: "electrical", subcategory: "wiring", description: "New electrical circuit installation", priceRange: "$200 - $500", rating: 4.9, reviews: 123, provider: "Circuit Pro", location: "Downtown", image: "⚡"},
    {id: 20, name: "Emergency Wiring Repair", category: "electrical", subcategory: "wiring", description: "24/7 emergency electrical wiring repair", priceRange: "$150 - $400", rating: 4.8, reviews: 234, provider: "Emergency Electric", location: "City Wide", image: "⚡"},
    
    {id: 21, name: "Socket Installation", category: "electrical", subcategory: "socket-installation", description: "Professional socket installation service", priceRange: "$60 - $120", rating: 4.9, reviews: 89, provider: "Sarah Johnson", location: "Midtown", image: "⚡"},
    {id: 22, name: "USB Socket Installation", category: "electrical", subcategory: "socket-installation", description: "Modern USB socket installation", priceRange: "$80 - $150", rating: 4.8, reviews: 67, provider: "Modern Electric", location: "Residential", image: "⚡"},
    {id: 23, name: "Switch Replacement", category: "electrical", subcategory: "socket-installation", description: "Light switch replacement and repair", priceRange: "$40 - $100", rating: 4.7, reviews: 134, provider: "Switch Masters", location: "Suburbs", image: "⚡"},
    {id: 24, name: "Dimmer Switch Install", category: "electrical", subcategory: "socket-installation", description: "Dimmer switch installation service", priceRange: "$70 - $140", rating: 4.9, reviews: 98, provider: "Dim Pro", location: "Downtown", image: "⚡"},
    {id: 25, name: "Outdoor Socket Setup", category: "electrical", subcategory: "socket-installation", description: "Weatherproof outdoor socket installation", priceRange: "$100 - $200", rating: 4.8, reviews: 156, provider: "Outdoor Electric", location: "Residential", image: "⚡"},
    
    // Mechanical Services
    {id: 26, name: "Engine Diagnostics", category: "mechanical", subcategory: "engine-service", description: "Complete vehicle engine diagnostics", priceRange: "$100 - $200", rating: 4.7, reviews: 156, provider: "Mike Wilson", location: "Industrial Area", image: "⚙️"},
    {id: 27, name: "Oil Change Service", category: "mechanical", subcategory: "engine-service", description: "Professional oil change and filter replacement", priceRange: "$50 - $120", rating: 4.8, reviews: 234, provider: "Quick Lube", location: "Downtown", image: "⚙️"},
    {id: 28, name: "Engine Tune-up", category: "mechanical", subcategory: "engine-service", description: "Complete engine tune-up service", priceRange: "$200 - $400", rating: 4.9, reviews: 89, provider: "Tune Masters", location: "Industrial", image: "⚙️"},
    {id: 29, name: "Cooling System Repair", category: "mechanical", subcategory: "engine-service", description: "Engine cooling system repair and maintenance", priceRange: "$150 - $350", rating: 4.7, reviews: 123, provider: "Cool Fix", location: "Suburbs", image: "⚙️"},
    {id: 30, name: "Transmission Service", category: "mechanical", subcategory: "engine-service", description: "Transmission fluid change and service", priceRange: "$120 - $250", rating: 4.8, reviews: 167, provider: "Trans Pro", location: "City Wide", image: "⚙️"},
    
    // Carpentry Services
    {id: 31, name: "Custom Dining Table", category: "carpentry", subcategory: "furniture-making", description: "Handcrafted custom dining table creation", priceRange: "$400 - $1000", rating: 4.9, reviews: 73, provider: "David Brown", location: "Arts District", image: "🪚"},
    {id: 32, name: "Kitchen Cabinets", category: "carpentry", subcategory: "furniture-making", description: "Custom kitchen cabinet design and build", priceRange: "$800 - $2000", rating: 4.8, reviews: 56, provider: "Cabinet Masters", location: "Residential", image: "🪚"},
    {id: 33, name: "Bookshelf Construction", category: "carpentry", subcategory: "furniture-making", description: "Custom bookshelf design and construction", priceRange: "$200 - $600", rating: 4.7, reviews: 89, provider: "Shelf Pro", location: "Downtown", image: "🪚"},
    {id: 34, name: "Wardrobe Building", category: "carpentry", subcategory: "furniture-making", description: "Built-in wardrobe construction service", priceRange: "$600 - $1500", rating: 4.9, reviews: 134, provider: "Wardrobe Works", location: "Suburbs", image: "🪚"},
    {id: 35, name: "Coffee Table Craft", category: "carpentry", subcategory: "furniture-making", description: "Artisan coffee table crafting service", priceRange: "$300 - $700", rating: 4.8, reviews: 98, provider: "Table Craft Co", location: "Arts District", image: "🪚"},
    
    // Painting Services
    {id: 36, name: "Living Room Painting", category: "painting", subcategory: "interior-painting", description: "Professional living room painting service", priceRange: "$200 - $500", rating: 4.6, reviews: 92, provider: "Lisa Garcia", location: "Residential Area", image: "🎨"},
    {id: 37, name: "Bedroom Wall Paint", category: "painting", subcategory: "interior-painting", description: "Bedroom wall painting and decoration", priceRange: "$150 - $400", rating: 4.8, reviews: 134, provider: "Room Painters", location: "Suburbs", image: "🎨"},
    {id: 38, name: "Kitchen Painting", category: "painting", subcategory: "interior-painting", description: "Kitchen wall and cabinet painting", priceRange: "$250 - $600", rating: 4.7, reviews: 78, provider: "Kitchen Paint Pro", location: "Residential", image: "🎨"},
    {id: 39, name: "Bathroom Paint Job", category: "painting", subcategory: "interior-painting", description: "Moisture-resistant bathroom painting", priceRange: "$180 - $450", rating: 4.9, reviews: 156, provider: "Bath Paint Co", location: "City Wide", image: "🎨"},
    {id: 40, name: "Office Interior Paint", category: "painting", subcategory: "interior-painting", description: "Professional office interior painting", priceRange: "$300 - $800", rating: 4.8, reviews: 89, provider: "Office Painters", location: "Business District", image: "🎨"},
    
    // Cleaning Services
    {id: 41, name: "Deep House Cleaning", category: "cleaning", subcategory: "home-cleaning", description: "Comprehensive home deep cleaning service", priceRange: "$100 - $250", rating: 4.8, reviews: 134, provider: "Clean Team Pro", location: "City Wide", image: "🧹"},
    {id: 42, name: "Kitchen Deep Clean", category: "cleaning", subcategory: "home-cleaning", description: "Thorough kitchen cleaning and sanitization", priceRange: "$80 - $180", rating: 4.9, reviews: 167, provider: "Kitchen Clean Co", location: "Residential", image: "🧹"},
    {id: 43, name: "Bathroom Sanitization", category: "cleaning", subcategory: "home-cleaning", description: "Complete bathroom cleaning and sanitization", priceRange: "$60 - $140", rating: 4.7, reviews: 203, provider: "Bath Clean Pro", location: "Suburbs", image: "🧹"},
    {id: 44, name: "Move-in Cleaning", category: "cleaning", subcategory: "home-cleaning", description: "Pre-move-in deep cleaning service", priceRange: "$150 - $350", rating: 4.8, reviews: 89, provider: "Move Clean", location: "City Wide", image: "🧹"},
    {id: 45, name: "Weekly House Clean", category: "cleaning", subcategory: "home-cleaning", description: "Regular weekly house cleaning service", priceRange: "$80 - $200", rating: 4.9, reviews: 234, provider: "Weekly Clean Co", location: "Residential", image: "🧹"},
    
    {id: 46, name: "Corporate Office Clean", category: "cleaning", subcategory: "office-cleaning", description: "Professional corporate office cleaning", priceRange: "$150 - $400", rating: 4.6, reviews: 45, provider: "Office Clean Co", location: "Business District", image: "🧹"},
    {id: 47, name: "Medical Office Sanitize", category: "cleaning", subcategory: "office-cleaning", description: "Medical-grade office sanitization", priceRange: "$200 - $500", rating: 4.9, reviews: 78, provider: "MedClean Pro", location: "Medical District", image: "🧹"},
    {id: 48, name: "Retail Store Cleaning", category: "cleaning", subcategory: "office-cleaning", description: "Retail store cleaning and maintenance", priceRange: "$100 - $300", rating: 4.7, reviews: 134, provider: "Retail Clean", location: "Shopping District", image: "🧹"},
    {id: 49, name: "Warehouse Cleaning", category: "cleaning", subcategory: "office-cleaning", description: "Industrial warehouse cleaning service", priceRange: "$300 - $800", rating: 4.8, reviews: 56, provider: "Warehouse Clean Co", location: "Industrial", image: "🧹"},
    {id: 50, name: "Restaurant Kitchen Clean", category: "cleaning", subcategory: "office-cleaning", description: "Commercial kitchen deep cleaning", priceRange: "$250 - $600", rating: 4.9, reviews: 123, provider: "Kitchen Pro Clean", location: "Restaurant District", image: "🧹"}
];

// Subcategories mapping
const subcategories = {
    plumbing: [
        { value: "pipe-installation", text: "Pipe Installation & Replacement" },
        { value: "tap-repair", text: "Tap and Shower Repair" },
        { value: "drainage", text: "Drainage Unblocking" },
        { value: "toilet-installation", text: "Toilet Installation & Repair" },
        { value: "water-tank", text: "Water Tank Installation" },
        { value: "leak-detection", text: "Leak Detection & Fixing" },
        { value: "bathroom-fitting", text: "Bathroom Fitting Services" }
    ],
    electrical: [
        { value: "wiring", text: "Wiring and Rewiring" },
        { value: "socket-installation", text: "Socket & Switch Installation" },
        { value: "lighting", text: "Lighting Fixtures Setup" },
        { value: "circuit-breaker", text: "Circuit Breaker Repair" },
        { value: "inspection", text: "Electrical Inspection & Troubleshooting" },
        { value: "generator", text: "Generator Installation & Maintenance" },
        { value: "appliance-repair", text: "Appliance Repair" }
    ],
    mechanical: [
        { value: "engine-service", text: "Vehicle Engine Service" },
        { value: "brake-repair", text: "Brake and Clutch Repair" },
        { value: "gearbox", text: "Gearbox Maintenance" },
        { value: "ac-repair", text: "AC System Repair" },
        { value: "motorcycle", text: "Motorcycle Repair & Tuning" },
        { value: "welding", text: "Welding & Fabrication" },
        { value: "pump-maintenance", text: "Generator & Pump Maintenance" }
    ],
    carpentry: [
        { value: "furniture-making", text: "Furniture Making" },
        { value: "door-installation", text: "Door Installation & Repair" },
        { value: "wardrobe", text: "Wardrobe & Shelving Design" },
        { value: "ceiling-work", text: "Ceiling & Partition Works" },
        { value: "floor-panel", text: "Floor Panel Installation" },
        { value: "polishing", text: "Furniture Polishing & Finishing" },
        { value: "custom-woodwork", text: "Custom Woodwork Projects" }
    ],
    painting: [
        { value: "interior-painting", text: "Interior Wall Painting" },
        { value: "exterior-painting", text: "Exterior House Painting" },
        { value: "ceiling-painting", text: "Ceiling Painting" },
        { value: "decorative", text: "Decorative & Texture Painting" },
        { value: "spray-painting", text: "Spray Painting for Furniture" },
        { value: "repainting", text: "Repainting & Touch-ups" },
        { value: "wallpaper", text: "Wallpaper Installation" }
    ],
    cleaning: [
        { value: "home-cleaning", text: "Home Cleaning" },
        { value: "office-cleaning", text: "Office Cleaning" },
        { value: "carpet-cleaning", text: "Carpet Cleaning" },
        { value: "event-cleanup", text: "After-Event Cleanup" },
        { value: "upholstery", text: "Upholstery & Sofa Cleaning" },
        { value: "window-cleaning", text: "Window Cleaning" },
        { value: "construction-cleanup", text: "Post-Construction Cleaning" }
    ]
};

function loadServices() {
    const urlParams = new URLSearchParams(window.location.search);
    const category = urlParams.get('category');
    
    if (category) {
        document.getElementById('category-filter').value = category;
        updateSubcategories();
    }
    
    renderServices(servicesData);
}

function setupFilters() {
    const categoryFilter = document.getElementById('category-filter');
    const subcategoryFilter = document.getElementById('subcategory-filter');
    const searchInput = document.getElementById('search');
    const ratingFilter = document.getElementById('rating-filter');
    
    categoryFilter.addEventListener('change', () => {
        updateSubcategories();
        applyFilters();
    });
    subcategoryFilter.addEventListener('change', applyFilters);
    searchInput.addEventListener('input', debounce(applyFilters, 300));
    ratingFilter.addEventListener('change', applyFilters);
}

function updateSubcategories() {
    const category = document.getElementById('category-filter').value;
    const subcategoryFilter = document.getElementById('subcategory-filter');
    
    subcategoryFilter.innerHTML = '<option value="">All Subcategories</option>';
    
    if (category && subcategories[category]) {
        subcategories[category].forEach(sub => {
            const option = document.createElement('option');
            option.value = sub.value;
            option.textContent = sub.text;
            subcategoryFilter.appendChild(option);
        });
    }
    subcategoryFilter.value = '';
}

function renderServices(services) {
    const grid = document.getElementById('services-grid');
    grid.innerHTML = '';
    
    services.forEach(service => {
        const serviceCard = createServiceCard(service);
        grid.appendChild(serviceCard);
    });
}

function createServiceCard(service) {
    const card = document.createElement('div');
    card.className = 'bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition';
    
    card.innerHTML = `
        <div class="p-6">
            <div class="flex items-center mb-4">
                <span class="text-3xl mr-3">${service.image}</span>
                <div>
                    <h3 class="text-lg font-semibold">${service.name}</h3>
                    <p class="text-gray-600 text-sm">${service.category.charAt(0).toUpperCase() + service.category.slice(1)}</p>
                </div>
            </div>
            <p class="text-gray-700 mb-4">${service.description}</p>
            <div class="flex items-center justify-between mb-4">
                <span class="text-primary font-semibold">${service.priceRange}</span>
                <div class="flex items-center">
                    <span class="text-yellow-400">★</span>
                    <span class="ml-1 text-sm">${service.rating} (${service.reviews})</span>
                </div>
            </div>
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm text-gray-600">Provider: ${service.provider}</p>
                    <p class="text-sm text-gray-500">📍 ${service.location}</p>
                </div>
                <button onclick="showServiceDetails(${service.id})" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition text-sm">
                    View Details
                </button>
            </div>
        </div>
    `;
    
    return card;
}

function applyFilters() {
    const category = document.getElementById('category-filter').value;
    const subcategory = document.getElementById('subcategory-filter').value;
    const search = document.getElementById('search').value.toLowerCase();
    const rating = parseFloat(document.getElementById('rating-filter').value) || 0;
    
    let filtered = servicesData.filter(service => {
        const matchesCategory = !category || service.category === category;
        const matchesSubcategory = !subcategory || service.subcategory === subcategory;
        const matchesSearch = !search || 
            service.name.toLowerCase().includes(search) ||
            service.provider.toLowerCase().includes(search) ||
            service.description.toLowerCase().includes(search);
        const matchesRating = service.rating >= rating;
        
        return matchesCategory && matchesSubcategory && matchesSearch && matchesRating;
    });
    
    renderServices(filtered);
}

function detectLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            (position) => {
                // In a real app, you would reverse geocode these coordinates
                document.getElementById('location').value = 'Current Location';
                showToast('Location detected successfully!', 'success');
            },
            (error) => {
                showToast('Unable to detect location. Please enter manually.', 'error');
            }
        );
    } else {
        showToast('Geolocation is not supported by this browser.', 'error');
    }
}

function showToast(message, type) {
    // Simple toast notification
    const toast = document.createElement('div');
    toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg text-white z-50 ${
        type === 'success' ? 'bg-green-500' : 'bg-red-500'
    }`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.remove();
    }, 3000);
}

function showServiceDetails(serviceId) {
    const service = servicesData.find(s => s.id === serviceId);
    if (!service) return;
    
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4';
    modal.onclick = (e) => { if (e.target === modal) closeServiceModal(); };
    
    modal.innerHTML = `
        <div class="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div class="p-6">
                <div class="flex justify-between items-start mb-6">
                    <div class="flex items-center">
                        <span class="text-4xl mr-4">${service.image}</span>
                        <div>
                            <h2 class="text-2xl font-bold">${service.name}</h2>
                            <p class="text-gray-600">${service.category.charAt(0).toUpperCase() + service.category.slice(1)} Service</p>
                        </div>
                    </div>
                    <button onclick="closeServiceModal()" class="text-gray-400 hover:text-gray-600">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                    </button>
                </div>
                
                <div class="grid md:grid-cols-2 gap-6 mb-6">
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold mb-2">Service Provider</h3>
                        <div class="flex items-center space-x-3">
                            <div class="w-12 h-12 bg-gray-300 rounded-full"></div>
                            <div>
                                <p class="font-medium">${service.provider}</p>
                                <div class="flex items-center">
                                    <span class="text-yellow-400">★★★★★</span>
                                    <span class="ml-2 text-sm text-gray-600">${service.rating} (${service.reviews} reviews)</span>
                                </div>
                                <span class="bg-green-100 text-green-800 px-2 py-1 rounded text-xs mt-1 inline-block">Verified</span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="bg-gray-50 p-4 rounded-lg">
                        <h3 class="font-semibold mb-2">Service Details</h3>
                        <div class="space-y-2">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Price Range:</span>
                                <span class="font-medium text-primary">${service.priceRange}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Duration:</span>
                                <span class="font-medium">2-4 hours</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Location:</span>
                                <span class="font-medium">📍 ${service.location}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Availability:</span>
                                <span class="font-medium text-green-600">Available Today</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mb-6">
                    <h3 class="font-semibold mb-3">Service Description</h3>
                    <p class="text-gray-700 leading-relaxed">${service.description}. Our experienced professionals use high-quality materials and modern techniques to ensure lasting results. All work comes with a satisfaction guarantee and warranty coverage.</p>
                </div>
                
                <div class="mb-6">
                    <h3 class="font-semibold mb-3">What's Included</h3>
                    <ul class="grid md:grid-cols-2 gap-2 text-sm text-gray-700">
                        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Professional consultation</li>
                        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Quality materials included</li>
                        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Clean-up after completion</li>
                        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> 30-day warranty</li>
                        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Licensed & insured</li>
                        <li class="flex items-center"><span class="text-green-500 mr-2">✓</span> Same-day service available</li>
                    </ul>
                </div>
                
                <div class="mb-6">
                    <h3 class="font-semibold mb-3">Recent Reviews</h3>
                    <div class="space-y-3">
                        <div class="border-l-4 border-primary pl-4">
                            <div class="flex items-center mb-1">
                                <span class="text-yellow-400">★★★★★</span>
                                <span class="ml-2 font-medium text-sm">Sarah M.</span>
                            </div>
                            <p class="text-sm text-gray-700">"Excellent service! Very professional and completed the work on time. Highly recommended!"</p>
                        </div>
                        <div class="border-l-4 border-primary pl-4">
                            <div class="flex items-center mb-1">
                                <span class="text-yellow-400">★★★★★</span>
                                <span class="ml-2 font-medium text-sm">Mike R.</span>
                            </div>
                            <p class="text-sm text-gray-700">"Great quality work at a fair price. The team was punctual and cleaned up after themselves."</p>
                        </div>
                    </div>
                </div>
                
                <div class="flex space-x-4">
                    <button onclick="bookService(${service.id})" class="flex-1 bg-primary text-white py-3 px-6 rounded-lg hover:bg-blue-600 transition font-medium">
                        Book Now
                    </button>
                    <button onclick="contactProvider(${service.id})" class="flex-1 border border-primary text-primary py-3 px-6 rounded-lg hover:bg-blue-50 transition font-medium">
                        Contact Provider
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

function closeServiceModal() {
    const modal = document.querySelector('.fixed.inset-0');
    if (modal) modal.remove();
}

function bookService(serviceId) {
    closeServiceModal();
    window.location.href = `booking-schedule.html?serviceId=${serviceId}`;
}

function contactProvider(serviceId) {
    const service = servicesData.find(s => s.id === serviceId);
    showToast(`Contact ${service.provider} at: contact@localpro.com`, 'info');
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}