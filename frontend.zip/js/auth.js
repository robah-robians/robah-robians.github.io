// Authentication functionality
document.addEventListener('DOMContentLoaded', function() {
    setupAuthTabs();
    setupForms();
});

function setupAuthTabs() {
    const loginTab = document.getElementById('login-tab');
    const signupTab = document.getElementById('signup-tab');
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');

    loginTab.addEventListener('click', () => {
        switchTab('login', loginTab, signupTab, loginForm, signupForm);
    });

    signupTab.addEventListener('click', () => {
        switchTab('signup', signupTab, loginTab, signupForm, loginForm);
    });
}

function switchTab(activeTab, activeBtn, inactiveBtn, activeForm, inactiveForm) {
    // Update button styles
    activeBtn.className = 'flex-1 py-2 px-4 rounded-md text-center font-medium transition bg-white text-primary shadow-sm';
    inactiveBtn.className = 'flex-1 py-2 px-4 rounded-md text-center font-medium transition text-gray-600 hover:text-primary';
    
    // Show/hide forms
    activeForm.classList.remove('hidden');
    inactiveForm.classList.add('hidden');
}

function setupForms() {
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');

    loginForm.addEventListener('submit', handleLogin);
    signupForm.addEventListener('submit', handleSignup);
}

function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Basic validation
    if (!email || !password) {
        showToast('Please fill in all fields', 'error');
        return;
    }
    
    // Simulate API call
    showLoader(true);
    
    setTimeout(() => {
        showLoader(false);
        
        // Simulate successful login
        const userData = {
            id: 1,
            name: 'John Doe',
            email: email,
            token: 'fake-jwt-token-' + Date.now()
        };
        
        // Store user data
        localStorage.setItem('user', JSON.stringify(userData));
        localStorage.setItem('authToken', userData.token);
        
        showToast('Login successful!', 'success');
        
        // Redirect to dashboard or previous page
        setTimeout(() => {
            const returnUrl = new URLSearchParams(window.location.search).get('return') || 'dashboard.html';
            window.location.href = returnUrl;
        }, 1000);
        
    }, 1500);
}

function handleSignup(e) {
    e.preventDefault();
    
    const name = document.getElementById('signup-name').value;
    const email = document.getElementById('signup-email').value;
    const phone = document.getElementById('signup-phone').value;
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('signup-confirm-password').value;
    const termsAccepted = document.getElementById('terms').checked;
    
    // Validation
    if (!name || !email || !phone || !password || !confirmPassword) {
        showToast('Please fill in all required fields', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showToast('Passwords do not match', 'error');
        return;
    }
    
    if (password.length < 6) {
        showToast('Password must be at least 6 characters long', 'error');
        return;
    }
    
    if (!termsAccepted) {
        showToast('Please accept the Terms of Service', 'error');
        return;
    }
    
    if (!isValidEmail(email)) {
        showToast('Please enter a valid email address', 'error');
        return;
    }
    
    // Simulate API call
    showLoader(true);
    
    setTimeout(() => {
        showLoader(false);
        
        // Simulate successful signup
        const userData = {
            id: Date.now(),
            name: name,
            email: email,
            phone: phone,
            token: 'fake-jwt-token-' + Date.now()
        };
        
        // Store user data
        localStorage.setItem('user', JSON.stringify(userData));
        localStorage.setItem('authToken', userData.token);
        
        showToast('Account created successfully!', 'success');
        
        // Redirect to dashboard
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1000);
        
    }, 2000);
}

function showLoader(show) {
    const submitBtns = document.querySelectorAll('button[type="submit"]');
    submitBtns.forEach(btn => {
        if (show) {
            btn.disabled = true;
            btn.innerHTML = '<span class="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span>Processing...';
        } else {
            btn.disabled = false;
            if (btn.closest('#login-form')) {
                btn.innerHTML = 'Sign In';
            } else {
                btn.innerHTML = 'Create Account';
            }
        }
    });
}

function showToast(message, type) {
    const toast = document.getElementById('toast');
    const toastMessage = document.getElementById('toast-message');
    
    toastMessage.textContent = message;
    toast.className = `fixed top-4 right-4 px-6 py-3 rounded-lg shadow-lg transform transition-transform duration-300 ${
        type === 'success' ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
    }`;
    
    // Show toast
    toast.style.transform = 'translateX(0)';
    
    // Hide after 3 seconds
    setTimeout(() => {
        toast.style.transform = 'translateX(100%)';
    }, 3000);
}

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Check if user is already logged in
function checkAuthStatus() {
    const token = localStorage.getItem('authToken');
    const user = localStorage.getItem('user');
    
    if (token && user) {
        // User is logged in, redirect to dashboard
        window.location.href = 'dashboard.html';
    }
}

// Call on page load
checkAuthStatus();